---
title: Blog
header: true
class: home
content:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true
---
